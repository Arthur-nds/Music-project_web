const addMusic = document.querySelector("#addMusic");

addMusic.addEventListener('click' , function () {
    const glass = 
});